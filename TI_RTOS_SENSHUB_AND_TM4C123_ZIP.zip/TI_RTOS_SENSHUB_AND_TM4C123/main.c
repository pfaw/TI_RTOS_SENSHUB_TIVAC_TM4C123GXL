/* This project uses TI-RTOS to handle the signaling and
 * processing of data from the senshub module while using the
 * TIVA C
 */

/*The project reads data and is able to print acceleration,
 * gyroscopic, and magnetometer data for x,y,z
 */


//added standard files
#include <stdio.h>
#include <string.h>

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>

//added xdc header files
#include <xdc/cfg/global.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Types.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

/* TI-RTOS Header files */
#include <ti/drivers/GPIO.h>
 #include <ti/drivers/I2C.h>
// #include <ti/drivers/SDSPI.h>
// #include <ti/drivers/SPI.h>
// #include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>
// #include <ti/drivers/WiFi.h>

/* Board Header file */
#include "Board.h"

//added mpu header file
#include "MPU9150.h"

//added GPIOTiva.h
#include <ti/drivers/gpio/GPIOTiva.h>
#include <ti/sysbios/knl/Semaphore.h>

//hw_mpu9150.h is for MPU9150.h
//mpu handle
static MPU9150_Handle mpu;

#define TASKSTACKSIZE   512



Task_Handle task0;
Task_Handle task1;

Task_Struct task0Struct;
Task_Struct task1Struct;

Char task0Stack[TASKSTACKSIZE];


//semaphore SampleData; signals when new data is available
Semaphore_Struct sampleDataStruct;
Semaphore_Handle sampleData;




void gpioPB2Fxn(unsigned int index);
Void dataCollectionTaskFxn(UArg arg0, UArg arg1);
Void dataPrintTaskFxn(UArg arg0, UArg arg1);

/*
 *  ======== main ========
 */
int main(void)
{

    Task_Params taskParams;
    Task_Params dataPrintParams;
    Semaphore_Params sampleDataParams;

//    Task_Params dataPrintParams;

    /* Call board init functions */
    Board_initGeneral();
    Board_initGPIO();
    Board_initI2C();



    //Board_PB2 edited and defined across Board.h and EK_TM4C123GXL.C
    //The configuration for this interrupt can be found in mentioned files
    //When senshub has data ready, the module sends a signal to PB2
    //PB2 then posts a semaphore which leads to further handling of sensor data
    GPIO_setCallback(Board_PB2, gpioPB2Fxn);
    //enable interrupts for PB2
    GPIO_enableInt(Board_PB2);

    /*construct semaphore sampleData*/
    sampleDataParams.mode = Semaphore_Mode_BINARY;
    Semaphore_Params_init(&sampleDataParams);
    Semaphore_construct(&sampleDataStruct, 0, &sampleDataParams);

    /* Obtain instance handle */
    sampleData = Semaphore_handle(&sampleDataStruct);

    /* Construct dataCollectionTaskFxn Task  thread */
    Task_Params_init(&taskParams);
    taskParams.arg0 = 1024;
    taskParams.stackSize = 1024;
    taskParams.priority = 2;

    Task_construct(&task0Struct, (Task_FuncPtr)dataCollectionTaskFxn, &taskParams, NULL);

    /*construct Void dataPrintTaskFxn(UArg arg0, UArg arg1) task*/
    Task_Params_init(&dataPrintParams);
    dataPrintParams.arg0 = 1024;
    dataPrintParams.stackSize = 1024;
    dataPrintParams.priority = 3;

    Task_construct(&task1Struct, (Task_FuncPtr)dataPrintTaskFxn, &dataPrintParams, NULL);


    System_printf("Starting BIOS\n");
    System_flush();
    /* Start BIOS */
    BIOS_start();

    return (0);
}

float dataArray[100];
int   arrayIndex = 0;



Void dataPrintTaskFxn(UArg arg0, UArg arg1){

    MPU9150_Data        accelData;
    MPU9150_Data        gyroData;
    MPU9150_Data         magData;

    float tmp;
    float tmp2;
    float tmp3;
    while(1){

        MPU9150_getGyroFloat(mpu, &accelData);
        tmp = accelData.yFloat;
        tmp2 = accelData.xFloat;
        tmp3 = accelData.zFloat;

        System_printf("y-axis acceleration: %f\n" , tmp);
        System_flush();

        Task_sleep(100);
    }//end of while(1)


}

Void dataCollectionTaskFxn(UArg arg0, UArg arg1){

       // notes: I2C_MPU9150_ADDR defined in board.h
       // notes: Board_I2C1 corresponds to I2C3 module
        System_printf("Calling MPU9150_init(). . . \n");
        System_flush();

        //MPU9150_init: is it 0x69 or 0x68??
        //It's 0x68
            //Refer to senshub documentation  for the address
        mpu = MPU9150_init(0, Board_I2C1, 0x68 );
        if (mpu == NULL) {
            System_abort("MPU9150 could not be initialized");
        }
        else{
            System_printf("MPU9150 SUCCESSFULLY INITIATED\n");
            System_flush();
        }


        while (1) {
            //semaphore waits until new data is available
               Semaphore_pend(sampleData, BIOS_WAIT_FOREVER);

               //read data registers
               if (!MPU9150_read(mpu)) {
                   System_abort("Could not extract data registers from the MPU9150");
               }
               else{
                   //You can add a message for this case
                   //When data has been successfully read
               }

           }
}



//When data is ready, senshub module sends a signal to PB2 pin
//then we callback to this function and it runs
void gpioPB2Fxn(unsigned int index){
        GPIO_clearInt(Board_PB2);
        Semaphore_post(sampleData);
}

